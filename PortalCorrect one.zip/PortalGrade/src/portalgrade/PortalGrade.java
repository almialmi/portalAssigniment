/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package portalgrade;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class PortalGrade {
    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) throws InterruptedException {
            System.setProperty("webdriver.chrome.driver", "C:\\Gecko\\chromedriver.exe");
            WebDriver driver;
            ChromeOptions chromeOptions= new ChromeOptions();
            driver=new ChromeDriver(chromeOptions);;
            chromeOptions.addArguments("--headless");
            chromeOptions.addArguments("--no-sandbox");

            String url="https://portal.aait.edu.et/";
            //Launch the some site
            driver.get(url);
            String username= "ATR/638309";
            String password= "5658";
            
            Thread.sleep(5000);
            driver.findElement(By.name("UserName")).clear();
            driver.findElement(By.name("UserName")).sendKeys(username);

            driver.findElement(By.name("Password")).clear();
            driver.findElement(By.name("Password")).sendKeys(password,Keys.ENTER);
            Thread.sleep(10000);
       // driver.findElement(By.id("m12")).click();
        driver.findElement(By.xpath("//a[@id='ml2']")).click();
         String l=driver.findElement(By.xpath("//table[@class='table table-bordered table-striped table-hover']")).getText();
          System.out.println(l);
          try{
          FileWriter file=new FileWriter("Report.txt");
          PrintWriter p=new PrintWriter(file);
          p.print("");
          p.append(driver.findElement(By.xpath("//table[@class='table table-bordered table-striped table-hover']")).getText());
          p.close();
          }
          catch(IOException e){
          e.printStackTrace();
          }
         System.out.println("successfully in");
         
            driver.quit();
        }
}
